﻿namespace B201210597.Models.DTO
{
    public class Status
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
    }
}